import urllib,urllib2,re,cookielib, urlresolver,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from resources.libs import main
import string

main_url = 'http://www.telepisodes.tv/'
art = main.art


def TELEPMAIN(index=False):
        main.addDir('Latest Updates','http://www.telepisodes.tv/updates/',952,art+'/.png')
        main.addDir('TV A-Z Index ','http://www.telepisodes.tv/tv-series/',951,art+'/.png')
        main.addDir('Popular Tv Shows ','http://www.telepisodes.tv/series/',962,art+'/.png')
       # main.addDir('Schedule ','http://www.telepisodes.tv/tv-guide/today/',953,art+'/.png')
        main.addDir('New Tv Shows','http://www.telepisodes.tv/series/new/',962,art+'/.png')
        main.addDir('Search','http://www.telepisodes.tv/search/',853,art+'/.png')
        main.addDir('Movies','http://www.telepisodes.tv/movies/',954,art+'/.png')
        


def TELEMV():
    main.addDir('0-9','http://www.telepisodes.ch/movies/letter/0-9/',952,art+'/09.png')
    for i in string.ascii_uppercase:
            main.addDir(i,'http://www.telepisodes.ch/movies/letter/'+i.upper()+'/',952,art+'/'+i.lower()+'.png')

def TELEAtoZ():
    main.addDir('0-9','http://www.telepisodes.ch/tv-series/letter/0-9/',952,art+'/09.png')
    for i in string.ascii_uppercase:
            main.addDir(i,'http://www.telepisodes.ch/tv-series/letter/'+i.upper()+'/',952,art+'/'+i.lower()+'.png')

def List(url):
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&#8211;',' - ').replace('&#8217;',"'").replace('amp;','')
        match=re.compile('<li><a href="(http://www.telepisodes.tv/tv-series/[^"]*?)">([^"]*?)</a></li>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url,name in match:
            #main.addPlayTE(name+' [COLOR red]'+date+'[/COLOR]',url,5,'','','','','','')
            url = url + 'search/'    
            main.addDirTE(name,url,959,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
        dialogWait.close()
        del dialogWait

def POPULAR(url):
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('class="link_cat_result" href="(http://www.telepisodes.tv/tv-series/[^"]*?)"><div class="clearfix"><span class="result_cat">([^"]*?)</span><img class="imgresult".+?src="//([^"]*?)" alt=').findall(link)
        for url,name,thumb in match:
         thumb='http://'+thumb       
         main.addDirTE(name,url,957,thumb,'','','','','')

        

def SCHEDULE(url):
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('href="(/tv-guide/[^"]*?)">([^"]*?)</a></td>').findall(link)
        for url,name in match:
         url='http://www.telepisodes.tv'+url       
         main.addDir(name,url,963,'')       
        
  
def SCHEDLIST(url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match=re.compile('<a class="tvlink" href=".+?"><img class="imgsched" src="//([^"]*?)".+?href=".+?">([^"]*?)</a></td>.+?#222;" class="tvlink" href="(http://www.telepisodes.tv/tv-series/[^"]*?)">(Season[^"]*?)</a>,.+?>(Episode[^"]*?)</a></td>.+?#000;" class="tvlink" href=".+?">([^"]*?)</a></td><td width="10%" style="font-size: 0.85em;">([^"]*?)</td>').findall(link)
        for thumb,name,url,season,episode,title,channel in match:
         url = url + 'search/'
         thumb='http://'+thumb       
         main.addDir(name+' '+season+' '+episode+' '+title+' '+channel,url,959,'')

     



def SEASONS(url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match=re.compile('href="(http://www.telepisodes.tv/tv-series/[^"]*?)"><span itemprop="name">(Season[^"]*?)</span>').findall(link)
        for url,name in match:
         main.addDir(name,url,958,'')

def EPISODES(url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match=re.compile('href="(http://www.telepisodes.tv/tv-series/[^"]*?)"><span style="float: left;" itemprop="name">(Episode[^"]*?)</span>([^"]*?)<meta itemprop="episodeNumber" content=".+?"/><span>([^"]*?)</span></a>').findall(link)
        for url,episode,name,airdate in match:
         url = url + 'search/'          
         main.addDir(episode+name+ '  '+ airdate,url,959,'')      
         
        
        
def LINKS(name,url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        name  = name.split('[COLOR blue]')[0]        
        match=re.compile('title="([^"]*?)" target="_blank" href="(/open/link/[^"]*?)" onclick').findall(link)
        for host,urls in match:
          url = 'http://www.telepisodes.tv' + urls       
          main.addDown2(name+" [COLOR blue] "+host.upper()+"[/COLOR]",str(url),961,art+'/hosts/'+host+'.png',art+'/hosts/'+host+'.png')

def GRABFINAL(name,url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match=re.compile('class="mybutton" href="(/open/site/[^"]*?)">Click Here to Play Video!</a>').findall(link)
        for url in match:
         url = 'http://www.telepisodes.tv' + url       
         PLAY(name,url)

        
       


def PLAY(name,url):
        sources = []
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\\','')
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Opening Link,2000)")
        match=re.compile('rel="canonical" href="([^"]*)"/><script>').findall(link)
        for url in match:
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('name="id" value="([^"]*?)"><input').findall(link)
        for url in match:
                url = 'http://played.to/' + url
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)        
        if (len(sources)==0):
                xbmc.executebuiltin("XBMC.Notification(Sorry!,Show doesn't have playable links,5000)")
      
        else:
                source = urlresolver.choose_source(sources)
                if source:
                        stream_url = source.resolve()
                        if source.resolve()==False:
                                xbmc.executebuiltin("XBMC.Notification(Sorry!,Cannot Play Link.,5000)")
                                return
                else:
                      stream_url = False
                      return
                listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
                listitem.setInfo('video', {'Title': name, 'Year': ''} )       
                xbmc.Player().play(str(stream_url), listitem)
                main.addDir('','','','')      

def Searchhistory():
    seapath=os.path.join(main.datapath,'Search')
    SeaFile=os.path.join(seapath,'SearchHistoryTV')
    if not os.path.exists(SeaFile):
        SEARCH()
    else:
        main.addDir('Search Shows','###',841,art+'/search.png')
        main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
        thumb=art+'/link.png'
        searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
        for seahis in reversed(searchis):
            url=seahis
            seahis=seahis.replace('%20',' ')
            main.addDir(seahis,url,841,thumb)

            

def SEARCH(url = ''):
        encode = main.updateSearchFile(url,'TV')
        if not encode: return False   
        surl='http://www.telepisodes.tv/search/' + encode.replace(' ','+')
        link=main.OPENURL(surl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('DELETE').findall(link)
        for url,name in match:
          main.addDir(name,url,846,'')      

        nextpage = re.compile('class="current">[^"]*</span><a href=\'([^"]*)\' class="inactive">[^"]*</a>').findall(link)
        for url in nextpage:
         main.addDir('[COLOR blue]''Next Page >>''[/COLOR]',url,841,'')
                
         xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
        main.VIEWS()
            







