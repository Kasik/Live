import urllib,re,sys,os,urllib2
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import main,string,cookielib
import urlresolver,base64
import time,json,datetime
import HTMLParser
from operator import itemgetter
from t0mm0.common.net import Net
from t0mm0.common.addon import Addon
from resources.universal import playbackengine, watchhistory
addon_id = 'plugin.video.movie25'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon('plugin.video.movie25', sys.argv)
art = 'https://raw.github.com/Kasik/MashupArtwork/master/skins/glossy'
base_url = 'http://www.primewire.ag/'
main_url = 'http://www.primewire.ag'

BASE_URL='http://www.primewire.ag'
net = Net()

USER_AGENT = ("User-Agent:Mozilla/5.0 (Windows NT 6.2; WOW64)"
              "AppleWebKit/537.17 (KHTML, like Gecko)"
              "Chrome/24.0.1312.56")

MOV_AZ = 'http://www.primewire.ag/?sort=alphabet'
MOV_FEAT = 'http://www.primewire.ag/?sort=featured'
MOV_POP = 'http://www.primewire.ag/?sort=views'
MOV_RATED = 'http://www.primewire.ag/?sort=ratings'
MOV_DATE_RELEASED = 'http://www.primewire.ag/?sort=release'
MOV_DATE_ADDED = 'http://www.primewire.ag/?sort=date'
MOV_SEARCH = 'http://www.primewire.ag/index.php?search_keywords='
MOV_FAVS = 'http://www.primewire.ag/?sort=favorites'


TV_POP = 'http://www.primewire.ag/?tv=&sort=views'
TV_RATED = 'http://www.primewire.ag/?tv=&sort=ratings'
TV_FAVS = 'http://www.primewire.ag/?tv=&sort=favorites'
TV_DATE_RELEASED = 'http://www.primewire.ag/?tv=&sort=release'
TV_DATE_ADDED = 'http://www.primewire.ag/?tv=&sort=date'
TV_AZ = 'http://www.primewire.ag/?tv=&sort=alphabet'
TV_FEAT = 'http://www.primewire.ag/?tv=&sort=featured'
TV_SEARCH = 'http://www.primewire.ag/index.php?search_keywords='


def PRIMEWIREMAIN(index=False):
        main.addDir('MOVIES','http://www.primewire.ag/',932,art+'/movies.png')
        main.addDir('TV SHOWS ','http://www.primewire.ag/?tv',933,art+'/television.png')

def PRIMEWIREMOVIES(index=False):        
        main.addDir('A-Z ',MOV_AZ,934,art+'/atoz.png')
        main.addDir('SEARCH',MOV_SEARCH,939,art+'/search.png')
        main.addDir('FAVORITES ',MOV_FAVS,938,art+'/favourites.png')
        main.addDir('GENRES',MOV_DATE_ADDED,936,art+'/genres.png')
        main.addDir('FEATURED',MOV_FEAT,938,art+'/featured.png')
        main.addDir('MOST POPULAR ',MOV_POP,938,art+'/most_popular.png')
        main.addDir('HIGHLY RATED',MOV_RATED,938,art+'/highly_rated.png')
        main.addDir('DATE RELEASED ',MOV_DATE_RELEASED,938,art+'/date_released.png')
        main.addDir('DATE ADDED',MOV_DATE_ADDED,938,art+'/date_added.png')
        
def PRIMEWIRETV(index=False):        
        main.addDir('A-Z ',TV_AZ,935,art+'/atoz.png')
        main.addDir('SEARCH',TV_SEARCH,940,art+'/search.png')
        main.addDir('FAVORITES ',TV_FAVS,947,art+'/favourites.png')
        main.addDir('GENRES',TV_DATE_ADDED,937,art+'/genres.png')
        main.addDir('FEATURED',TV_FEAT,947,art+'/featured.png')
        main.addDir('MOST POPULAR ',TV_POP,947,art+'/most_popular.png')
        main.addDir('HIGHLY RATED',TV_RATED,947,art+'/highly_rated.png')
        main.addDir('DATE RELEASED ',TV_DATE_RELEASED,947,art+'/date_released.png')
        main.addDir('DATE ADDED',TV_DATE_ADDED,947,art+'/date_added.png')
        


def PRIMEMVAtoZ():
    main.addDir('0-9',main_url+'/?sort=alphabet&letter=1',938,art+'/123.png')
    for i in string.ascii_uppercase:
            main.addDir(i,main_url+'/?sort=alphabet&letter='+i.upper(),938,art+'/'+i.lower()+'.png')

def PRIMETVAtoZ(): #http://www.primewire.ag/?tv=&sort=alphabet#
    main.addDir('0-9',main_url+'/?tv=&sort=alphabet&letter=1',947,art+'/09.png')
    for i in string.ascii_uppercase:
            main.addDir(i,main_url+'/?tv=&sort=alphabet&letter='+i.upper(),947,art+'/'+i.lower()+'.png')            


def PRIMEMOVIES(murl,index=False):
    link=main.OPENURL(murl)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    match = re.findall('class="index_item index_item_ie"><a href="([^"]*?)" title="Watch ([^"]*?)"><img src="([^"]*?)" border=".+?" width="150" height="225" alt=".+?"><h2>',link)   
    dialogWait = xbmcgui.DialogProgress()
    ret = dialogWait.create('Please wait until Movie list is cached.')
    totalLinks = len(match)
    loadedLinks = 0
    remaining_display = 'Movies loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
    dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
    xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")
    for url,name,thumb in match:
        url = main_url + url    
        if index == 'True':
            main.addInfo(name,url,945,thumb,'','')
        else:
            main.addInfo(name,url,945,thumb,'','')
        loadedLinks = loadedLinks + 1
        percent = (loadedLinks * 100)/totalLinks
        remaining_display = 'Movies loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
        if dialogWait.iscanceled(): return False   
    dialogWait.close()
    del dialogWait
     
    paginate=re.compile('class="pagination"><span class=current>.+?</span> <a href="([^"]*?)">.+?</a>').findall(link)
    if paginate:
        xurl=main_url+paginate[0]
        main.addDir('[COLOR blue]Next Page -> [/COLOR]',xurl,938,art+'/next2.png',index=index)

    xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
    main.VIEWS()



def PRIMEMVGENRE(url):
        main.addDir('Action',main_url+'/?genre=Action',938,art+'/action.png','')
        main.addDir('Adventure',main_url+'/?genre=Adventure',938,art+'/adventure.png','')
        main.addDir('Animation',main_url+'/?genre=Animation',938,art+'/animation.png','')
        main.addDir('Biography',main_url+'/?genre=Biography',938,art+'/biography.png','')
        main.addDir('Comedy',main_url+'/?genre=Comedy',938,art+'/comedy.png','')
        main.addDir('Crime',main_url+'/?genre=Crime',938,art+'/crime.png','')
        main.addDir('Documentary',main_url+'/?genre=Documentary',938,art+'/documentary.png','')
        main.addDir('Drama',main_url+'/?genre=Drama',938,art+'/drama.png','')
        main.addDir('Family',main_url+'/?genre=Family',938,art+'/family.png','')
        main.addDir('Fantasy',main_url+'/?genre=Fantasy',938,art+'/fantasy.png','')
        main.addDir('Game-Show',main_url+'/?genre=Game-Show',938,art+'/game-show.png','')
        main.addDir('History',main_url+'/?genre=History',938,art+'/history.png','')
        main.addDir('Horror',main_url+'/?genre=Horror',938,art+'/horror.png','')
        main.addDir('Japanese',main_url+'/?genre=Japanese',938,art+'/japanese.png','')
        main.addDir('Korean',main_url+'/?genre=Korean',938,art+'/korean.png','')
        main.addDir('Music',main_url+'/?genre=Music',938,art+'/music.png','')
        main.addDir('Musical',main_url+'/?genre=Musical',938,art+'/musical.png','')
        main.addDir('Mystery',main_url+'/?genre=Mystery',938,art+'/mystery.png','')
        main.addDir('Reality-TV',main_url+'/?genre=Reality-TV',938,art+'/reality-tv.png','')
        main.addDir('Romance',main_url+'/?genre=Romance',938,art+'/romance.png','')
        main.addDir('Sci-Fi',main_url+'/?genre=Sci-Fi',938,art+'/sci-fi.png','')
        main.addDir('Short',main_url+'/?genre=Short',938,art+'/short.png','') 
        main.addDir('Sport',main_url+'/?genre=Sport',938,art+'/sport.png','')
        main.addDir('Talk-Show',main_url+'/?genre=Talk-Show',938,art+'/talk-show.png','')
        main.addDir('Thriller',main_url+'/?genre=Thriller',938,art+'/thriller.png','')
        main.addDir('War',main_url+'/?genre=War',938,art+'/war.png','')
        main.addDir('Western',main_url+'/?genre=Western',938,art+'/western.png','')
        main.addDir('Zombies',main_url+'/?genre=Zombies',938,art+'/zombies.png','')



            

def PRIMETVGENRE(url):
        main.addDir('Action',main_url+'/?tv&genre=Action',947,art+'/action.png','')
        main.addDir('Adventure',main_url+'/?tv&genre=Adventure',947,art+'/adventure.png','')
        main.addDir('Animation',main_url+'/?tv&genre=Animation',947,art+'/animation.png','')
        main.addDir('Biography',main_url+'/?tv&genre=Biography',947,art+'/biography.png','')
        main.addDir('Comedy',main_url+'/?tv&genre=Comedy',947,art+'/comedy.png','')
        main.addDir('Crime',main_url+'/?tv&genre=Crime',947,art+'/crime.png','')
        main.addDir('Documentary',main_url+'/?tv&genre=Documentary',947,art+'/documentary.png','')
        main.addDir('Drama',main_url+'/?tv&genre=Drama',947,art+'/drama.png','')
        main.addDir('Family',main_url+'/?tv&genre=Family',947,art+'/family.png','')
        main.addDir('Fantasy',main_url+'/?tv&genre=Fantasy',947,art+'/fantasy.png','')
        main.addDir('Game-Show',main_url+'/?tv&genre=Game-Show',947,art+'/game-show.png','')
        main.addDir('History',main_url+'/?tv&genre=History',947,art+'/history.png','')
        main.addDir('Horror',main_url+'/?tv&genre=Horror',947,art+'/horror.png','')
        main.addDir('Japanese',main_url+'/?tv&genre=Japanese',947,art+'/japanese.png','')
        main.addDir('Korean',main_url+'/?tv&genre=Korean',947,art+'/korean.png','')
        main.addDir('Music',main_url+'/?tv&genre=Music',947,art+'/music.png','')
        main.addDir('Musical',main_url+'/?tv&genre=Musical',947,art+'/musical.png','')
        main.addDir('Mystery',main_url+'/?tv&genre=Mystery',947,art+'/mystery.png','')
        main.addDir('Reality-TV',main_url+'/?tv&genre=Reality-TV',947,art+'/reality-tv.png','')
        main.addDir('Romance',main_url+'/?tv&genre=Romance',947,art+'/romance.png','')
        main.addDir('Sci-Fi',main_url+'/?tv&genre=Sci-Fi',947,art+'/sci-fi.png','')
        main.addDir('Short',main_url+'/?tv&genre=Short',947,art+'/short.png','') 
        main.addDir('Sport',main_url+'/?tv&genre=Sport',947,art+'/sport.png','')
        main.addDir('Talk-Show',main_url+'/?tv&genre=Talk-Show',947,art+'/talk-show.png','')
        main.addDir('Thriller',main_url+'/?tv&genre=Thriller',947,art+'/thriller.png','')
        main.addDir('War',main_url+'/?tv&genre=War',947,art+'/war.png','')
        main.addDir('Western',main_url+'/?tv&genre=Western',947,art+'/western.png','')
        main.addDir('Zombies',main_url+'/?tv&genre=Zombies',947,art+'/zombies.png','')

    

def PRIMETV(murl,index=False):
    link=main.OPENURL(murl)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    match = re.findall('class="index_item index_item_ie"><a href="([^"]*?)" title="Watch ([^"]*?)"><img src="([^"]*?)" border=".+?" width="150" height="225" alt=".+?"><h2>',link)   
    dialogWait = xbmcgui.DialogProgress()
    ret = dialogWait.create('Please wait until Show list is cached.')
    totalLinks = len(match)
    loadedLinks = 0
    remaining_display = 'Shows loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
    dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
    xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")
    for url,name,thumb in match:
        if index == 'True':
            main.addDirTE(name,main_url+url,948,thumb,'','','','','')
        else:
            main.addDirTE(name,main_url+url,948,thumb,'','','','','')
        loadedLinks = loadedLinks + 1
        percent = (loadedLinks * 100)/totalLinks
        remaining_display = 'Shows loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
        if dialogWait.iscanceled(): return False   
    dialogWait.close()
    del dialogWait
     
    paginate=re.compile('class="pagination"><span class=current>.+?</span> <a href="([^"]*?)">.+?</a>').findall(link)
    if paginate:
        xurl=main_url+paginate[0]
        main.addDir('[COLOR blue]Next Page -> [/COLOR]',xurl,947,art+'/next2.png',index=index)

    xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
    main.VIEWS()            

def SEASONS(name,url):
        link=main.OPEN_URL(url)
        match=re.compile('href="([^"]*?)">&#9658; Season([^"]*?)<span').findall(link)
        for url,name in match:
            main.addDir('Season '+name,main_url+url,949,'')

def EPISODES(name,url):
        link=main.OPEN_URL(url)
        match=re.compile('<a href="([^"]*?)">E([^"]*?)<span class="tv_episode_name">([^"]*?)</span><span class="tv_episode_airdate">([^"]*?)</span>').findall(link)
        for url,episode,name,date in match:
            main.addDir("[COLOR green]Episode "+episode+"[/COLOR] "+" [COLOR white] "+name+"[/COLOR]"+" [COLOR red] "+date+"[/COLOR]",main_url+url,945,'')            


################################################################# VIDEOLINKS TEST ######################################################
def VIDEOLINKS(name,url):

        link=OPEN_URL(url)
        match=re.compile('href="([^"]*?)">&#9658; Season([^"]*?)<span').findall(link)
        for url,name in match:
         url = main_url + url       
         main.addDir("[COLOR yellow] Season "+name+"[/COLOR]",url,949,'')
        
        html=OPEN_URL(url)
        html=html.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        
        match=re.compile('<span class=quality_([^"]*?)></span>.+?class="movie_version_link"><a href="/external.php[?]title=.+?&url=(.+?)&domain=.+?=&loggedin=0".+?document.writeln[(]\'(.+?)\'[)];</script>').findall(html)
        sortorder = "putlocker,firedrive,sockshare,bestreams,billionuploads,hugefiles,mightyupload,movreel,lemuploads,180upload,megarelease,filenuke,flashx,gorillavid,bayfiles,veehd,vidto,epicshare,2gbhosting,alldebrid,allmyvideos,castamp,cheesestream,clicktoview,crunchyroll,cyberlocker,daclips,dailymotion,divxstage,donevideo,ecostream,entroupload,facebook,filebox,hostingbulk,hostingcup,jumbofiles,limevideo,movdivx,movpod,movshare,movzap,muchshare,nolimitvideo,nosvideo,novamov,nowvideo,ovfile,play44_net,played,playwire,premiumize_me,primeshare,promptfile,purevid,rapidvideo,realdebrid,rpnet,seeon,sharefiles,sharerepo,sharesix,skyload,stagevu,stream2k,streamcloud,thefile,thevideo,tubeplus,tunepk,ufliq,upbulk,uploadc,uploadcrazynet,veoh,vidbull,vidcrazynet,video44,videobb,videofun,videotanker,videoweed,videozed,videozer,vidhog,vidpe,vidplay,vidstream,vidup_org,vidx,vidxden,vidzi,vidzur,vimeo,vureel,watchfreeinhd,xvidstage,yourupload,youtube,youwatch,zalaa,zooupload,zshare,cloudyvideos,streamin,realvid,wavymotion,playhd,vodlocker,ipithos,realvid,yourvideohost,cloudzilla"
        sortorder = ','.join((sortorder.split(',')[::-1]))    
        for q,url,host in match:
         url = url.decode('base-64')
         if 'host' in sortorder:
          host=host.replace('.me','').replace('.to','').replace('.net','').replace('.sx','').replace('.com','').replace('.co','').replace('.eu','')       
          main.addDown2(name+" [COLOR red]"+q.upper()+"[/COLOR]"+" [COLOR blue]"+host.upper()+"[/COLOR]",url,946,'','')

        parts=re.compile('<span class=quality_([^"]*?)></span>.+?target="_blank">.+?</a>[[]<a href="/external.php[?]title=.+?&url=(.+?)&domain=.+?&loggedin=0".+?Part(.+?)</a>.+?document.writeln[(]\'(.+?)\'[)];</script>').findall(html)
        sortorder = "putlocker,firedrive,sockshare,bestreams,billionuploads,hugefiles,mightyupload,movreel,lemuploads,180upload,megarelease,filenuke,flashx,gorillavid,bayfiles,veehd,vidto,epicshare,2gbhosting,alldebrid,allmyvideos,castamp,cheesestream,clicktoview,crunchyroll,cyberlocker,daclips,dailymotion,divxstage,donevideo,ecostream,entroupload,facebook,filebox,hostingbulk,hostingcup,jumbofiles,limevideo,movdivx,movpod,movshare,movzap,muchshare,nolimitvideo,nosvideo,novamov,nowvideo,ovfile,play44_net,played,playwire,premiumize_me,primeshare,promptfile,purevid,rapidvideo,realdebrid,rpnet,seeon,sharefiles,sharerepo,sharesix,skyload,stagevu,stream2k,streamcloud,thefile,thevideo,tubeplus,tunepk,ufliq,upbulk,uploadc,uploadcrazynet,veoh,vidbull,vidcrazynet,video44,videobb,videofun,videotanker,videoweed,videozed,videozer,vidhog,vidpe,vidplay,vidstream,vidup_org,vidx,vidxden,vidzi,vidzur,vimeo,vureel,watchfreeinhd,xvidstage,yourupload,youtube,youwatch,zalaa,zooupload,zshare,cloudyvideos,streamin,realvid,wavymotion,playhd,vodlocker,ipithos,realvid,yourvideohost,cloudzilla"
        sortorder = ','.join((sortorder.split(',')[::-1]))
        for quality,urls,part,host in parts:
         url = url.decode('base-64')
         if 'host' in sortorder:
            host=host.replace('.me','').replace('.to','').replace('.net','').replace('.sx','').replace('.com','').replace('.co','').replace('.eu','')   
            main.addDown2(name+" [COLOR red]"+quality.upper()+"[/COLOR]"+" [COLOR blue]"+host.upper()+"[/COLOR]"+" [COLOR yellow] Part "+part+"[/COLOR]",url,946,'','')

        matchtv=re.compile('class="movie_version_link">.+?<a href="/external.php[?]title=.+?&url=(.+?)&domain=.+?=&loggedin=0".+?document.writeln[(]\'(.+?)\'[)];</script>').findall(html)
        sortorder = "putlocker,firedrive,sockshare,bestreams,billionuploads,hugefiles,mightyupload,movreel,lemuploads,180upload,megarelease,filenuke,flashx,gorillavid,bayfiles,veehd,vidto,epicshare,2gbhosting,alldebrid,allmyvideos,castamp,cheesestream,clicktoview,crunchyroll,cyberlocker,daclips,dailymotion,divxstage,donevideo,ecostream,entroupload,facebook,filebox,hostingbulk,hostingcup,jumbofiles,limevideo,movdivx,movpod,movshare,movzap,muchshare,nolimitvideo,nosvideo,novamov,nowvideo,ovfile,play44_net,played,playwire,premiumize_me,primeshare,promptfile,purevid,rapidvideo,realdebrid,rpnet,seeon,sharefiles,sharerepo,sharesix,skyload,stagevu,stream2k,streamcloud,thefile,thevideo,tubeplus,tunepk,ufliq,upbulk,uploadc,uploadcrazynet,veoh,vidbull,vidcrazynet,video44,videobb,videofun,videotanker,videoweed,videozed,videozer,vidhog,vidpe,vidplay,vidstream,vidup_org,vidx,vidxden,vidzi,vidzur,vimeo,vureel,watchfreeinhd,xvidstage,yourupload,youtube,youwatch,zalaa,zooupload,zshare,cloudyvideos,streamin,realvid,wavymotion,playhd,vodlocker,ipithos,realvid,yourvideohost,cloudzilla"
        sortorder = ','.join((sortorder.split(',')[::-1]))
        for url,host in matchtv:
         url = url.decode('base-64')   
         if 'host' in sortorder:
            host=host.replace('.me','').replace('.to','').replace('.net','').replace('.sx','').replace('.com','').replace('.co','').replace('.eu','')   
            main.addDown2(name+" [COLOR blue]"+host.upper()+"[/COLOR]",url,946,'','')  

        adultregex = '<div class="offensive_material">.+<a href="(.+)">I understand'
        r = re.search(adultregex, html, re.DOTALL)
        if r:
            try: addon.log('Adult content url detected')
            except: pass
            adulturl = BASE_URL + r.group(1)
            headers = {'Referer': url}
            cookiejar = addon.get_profile()
            cookiejar = os.path.join(cookiejar, 'primewire')
            net.set_cookies(cookiejar)
            html = net.http_GET(adulturl, headers=headers).content
            net.save_cookies(cookiejar)
            
            html=OPEN_URL(url)
            html=html.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')            
            match=re.compile('class=quality_([^"]*?)></span>.+?<a href="/external.php[?]title=.+?&url=([^"]*?)=&domain=.+?&loggedin=0".+?document.writeln[(]\'([^"]*?)\'[)];</script>').findall(html)
            sortorder = "putlocker,firedrive,sockshare,bestreams,billionuploads,hugefiles,mightyupload,movreel,lemuploads,180upload,megarelease,filenuke,flashx,gorillavid,bayfiles,veehd,vidto,epicshare,2gbhosting,alldebrid,allmyvideos,castamp,cheesestream,clicktoview,crunchyroll,cyberlocker,daclips,dailymotion,divxstage,donevideo,ecostream,entroupload,facebook,filebox,hostingbulk,hostingcup,jumbofiles,limevideo,movdivx,movpod,movshare,movzap,muchshare,nolimitvideo,nosvideo,novamov,nowvideo,ovfile,play44_net,played,playwire,premiumize_me,primeshare,promptfile,purevid,rapidvideo,realdebrid,rpnet,seeon,sharefiles,sharerepo,sharesix,skyload,stagevu,stream2k,streamcloud,thefile,thevideo,tubeplus,tunepk,ufliq,upbulk,uploadc,uploadcrazynet,veoh,vidbull,vidcrazynet,video44,videobb,videofun,videotanker,videoweed,videozed,videozer,vidhog,vidpe,vidplay,vidstream,vidup_org,vidx,vidxden,vidzi,vidzur,vimeo,vureel,watchfreeinhd,xvidstage,yourupload,youtube,youwatch,zalaa,zooupload,zshare,cloudyvideos,streamin,realvid,wavymotion,playhd,vodlocker,ipithos,realvid,yourvideohost,cloudzilla"
            sortorder = ','.join((sortorder.split(',')[::-1]))    
            for q,urls,host in match:
             url=base64.urlsafe_b64decode(urls + '=' * (len(urls)))            
             if 'host' in sortorder:
              host=host.replace('.me','').replace('.to','').replace('.net','').replace('.sx','').replace('.com','').replace('.co','').replace('.eu','')          
              main.addDown2(name+" [COLOR red]"+q.upper()+"[/COLOR]"+" [COLOR blue]"+host.upper()+"[/COLOR]",url,946,'','')

            
##############################################################################################################################    




def PLAY(name,murl):
    ok=True
    hname=name
    name  = name.split('[COLOR blue]')[0]
    name  = name.split('[COLOR red]')[0]
    infoLabels = main.GETMETAT(name,'','','')
    murl = murl
    if not murl: return False
    #murl = murl
    #if not murl: return True
    print "Is The File Playing ? " + murl
    video_type='movie'
    season=''
    episode=''
    img=infoLabels['cover_url']
    fanart =infoLabels['backdrop_url']
    imdb_id=infoLabels['imdb_id']
    infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':str(infoLabels['title']), 'imdb_id':str(infoLabels['imdb_id']), 'season':str(season), 'episode':str(episode), 'year':str(infoLabels['year']) }

    try:
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
        #stream_url = main.resolve_url(murl)
        stream_url = urlresolver.resolve(str(murl))

        infoL={'Title': infoLabels['metaName'], 'Plot': infoLabels['plot'], 'Genre': infoLabels['genre']}
        # play with bookmark
        from resources.universal import playbackengine
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=stream_url, addon_id=addon_id, video_type=video_type, title=str(infoLabels['title']),season=str(season), episode=str(episode), year=str(infoLabels['year']),img=img,infolabels=infoL, watchedCallbackwithParams=main.WatchedCallbackwithParams,imdb_id=imdb_id)
        player.KeepAlive()
        return ok
    except Exception, e:
        if stream_url != False:
                main.ErrorReport(e)
        return ok






def SearchhistoryMV():
    seapath=os.path.join(main.datapath,'Search')
    SeaFile=os.path.join(seapath,'SearchHistoryMV')
    if not os.path.exists(SeaFile):
        SEARCHMV()
    else:
        main.addDir('Search Movies','###',941,art+'/search.png')
        main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
        thumb=art+'/link.png'
        searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
        for seahis in reversed(searchis):
            url=seahis
            seahis=seahis.replace('%20',' ')
            main.addDir(seahis,url,941,thumb)


def SearchhistoryTV():
    seapath=os.path.join(main.datapath,'Search')
    SeaFile=os.path.join(seapath,'SearchHistoryTV')
    if not os.path.exists(SeaFile):
        SEARCHTV()
    else:
        main.addDir('Search Shows','###',942,art+'/search.png')
        main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
        thumb=art+'/link.png'
        searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
        for seahis in reversed(searchis):
            url=seahis
            seahis=seahis.replace('%20',' ')
            main.addDir(seahis,url,942,thumb)



def SEARCHMV(url = ''):
    encode = main.updateSearchFile(url,'Movies')
    if not encode: return False   
    surl='http://www.primewire.ag/index.php?search_keywords='+encode+'&key=b2d70a3083f9167b&search_section=1' 
    link=main.OPENURL(surl)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    match = re.findall('class="index_item index_item_ie"><a href="([^"]*?)" title="Watch ([^"]*?)"><img src="([^"]*?)" border=".+?" width="150" height="225" alt=".+?"><h2>',link)   
    dialogWait = xbmcgui.DialogProgress()
    ret = dialogWait.create('Please wait until Movie list is cached.')
    totalLinks = len(match)
    loadedLinks = 0
    remaining_display = 'Movies loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
    dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
    xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")
    for url,name,thumb in match:
        main.addInfo(name,main_url+url,945,thumb,'','')      

    nextpage=re.compile('class="pagination"><span class=current>.+?</span> <a href="([^"]*?)">.+?</a>').findall(link)
    if nextpage:
     xurl=main_url+nextpage[0]       
     main.addDir('[COLOR blue]Next Page -> [/COLOR]',xurl,938,art+'/next2.png','')
                
    xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
    main.VIEWS()


            

def SEARCHTV(url = ''):
    encode = main.updateSearchFile(url,'TV')
    if not encode: return False   
    surl='http://www.primewire.ag/index.php?search_keywords='+encode+'&key=4a9e2ec69f6ebd28&search_section=2' 
    link=main.OPENURL(surl)
    link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    match = re.findall('class="index_item index_item_ie"><a href="([^"]*?)" title="Watch ([^"]*?)"><img src="([^"]*?)" border=".+?" width="150" height="225" alt=".+?"><h2>',link)   
    dialogWait = xbmcgui.DialogProgress()
    ret = dialogWait.create('Please wait until Show list is cached.')
    totalLinks = len(match)
    loadedLinks = 0
    remaining_display = 'Shows loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
    dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
    xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")
    for url,name,thumb in match:
        main.addDirTE(name,main_url+url,948,thumb,'','','','','')
        loadedLinks = loadedLinks + 1
        percent = (loadedLinks * 100)/totalLinks
        remaining_display = 'Shows loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
        if dialogWait.iscanceled(): return False   
    dialogWait.close()
    del dialogWait
     
    paginate=re.compile('class="pagination"><span class=current>.+?</span> <a href="([^"]*?)">.+?</a>').findall(link)
    if paginate:
        xurl=main_url+paginate[0]
        main.addDir('[COLOR blue]Next Page -> [/COLOR]',xurl,942,art+'/next2.png',index=index)




#########################

def OPEN_URL(url):
    req = urllib2.Request(url)
    import time
    #time.sleep(5)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    #link=response.read().replace('&amp;','&').replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%3B',';').replace('crawler','')#.replace(';v=1','')
    link=response.read().replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
    response.close()
    return link


################################################

