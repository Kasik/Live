import urllib,urllib2,re,cookielib, urlresolver,sys,os
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from resources.libs import main
import string

#http://tvlinks1.com - by Kasik04a 2015

from t0mm0.common.addon import Addon
from resources.universal import playbackengine, watchhistory
addon_id = 'plugin.video.movie25'
selfAddon = xbmcaddon.Addon(id=addon_id)
art = xbmc.translatePath('special://home/addons/plugin.video.movie25/resources/art/')
base_url = 'http://tvlinks1.com'
main_url = 'http://tvlinks1.com/'


def TVLINKSMAIN(index=False):
        main.addDir('Latest Episodes','http://tvlinks1.com/last-updates',839,art+'/tvlatest.png')
        main.addDir('TV A-Z Index ','http://tvlinks1.com/tvshows/',849,art+'/tvaz.png')
        main.addDir('Schedule ','http://tvlinks1.com/tvschedule/0',844,art+'/tvsched.png')
        main.addDir('Search','http://tvlinks1.com/search/',853,art+'/tvsrch.png')
        main.VIEWSB()


def CCAtoZ():
    main.addDir('#','http://tvlinks1.com/tvshows/#',845,art+'/#.png')
    main.addDir('0-9','http://tvlinks1.com/tvshows/09',845,art+'/09.png')
    for i in string.ascii_uppercase:
            main.addDir(i,'http://tvlinks1.com/tvshows/'+i.upper(),845,art+'/'+i.lower()+'.png')
    

def List(url):
        link=main.OPEN_URL(url)
        match=re.compile('<li> <a href="([^"]*?)"><span style="color:#000; font-size:12px;">&raquo;</span>([^"]*?)</a></li>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url,name in match:
            main.addDirTE(name,url,843,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
        dialogWait.close()
        del dialogWait

def List2(url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match=re.compile('<li><a href="(/tvschedule/[^"]*?)">([^"]*?)</a></li>').findall(link)
        for url,name in match:
         url = base_url + url       
         main.addDir(name,url,851,'')

def List3(url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match=re.compile('<li><a href="(http://tvlinks1.com/[^"]*?)">([^"]*?)</a></li>').findall(link)
        for url,name in match:
         url = base_url + url     
         main.addDir(name,url,843,'')         
        



def Alpha(url):
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match = re.compile('<li><a href="([^"]*?)">([^"]*?)</a><span class="epnum">([^"]*?)</span></li>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url,name,date in match:
            main.addDirTE(name+' - '+date,url,846,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
        dialogWait.close()
        del dialogWait
            
def Alpha2(url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match = re.compile('class="lists"><a href="([^"]*?)">([^"]*?)</a></h2>').findall(link)
        for url,name in match:
            main.addDirTE(name,url,850,'','','','','','')

def Alpha3(url):
        link=main.OPENURL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&player=2','').replace("",'').replace('\xe2\x80\x99',"'").replace('\xe2\x80\x93','-')
        match = re.compile('<li><a href="([^"]*?)"><span>([^"]*?)</span><span class="epnum">([^"]*?)</span>').findall(link)
        for url,name,date in match:
            main.addDirTE(name+'  '+date,url,843,'','','','','','')

                    

            
            

        
        
def LINK(name,url):      
        html = main.OPEN_URL(url)
        main.addLink("[COLOR red]For Download Options, Bring up Context Menu Over Selected Link.[/COLOR]",'','')
        r = re.compile(r'<a title="([^"]*?)" rel="nofollow" target="_blank" href="([^"]*?)" class="vtlink"',re.M|re.DOTALL).findall(html)
        if len(r)== 0:
         main.addLink("[COLOR yellow]Sorry No Links Added Yet.[/COLOR]",'','')
        else:
         for host,url in r:
          url = base_url+url
          main.addDown2(name.strip()+" [COLOR blue]"+host.upper()+"[/COLOR]",url,848,art+'/hosts/'+host+'.png',art+'/hosts/'+host+'.png')
             

def LINK2(name,url):
        html = main.OPENURL(url)
        #main.addLink("[COLOR red]For Download Options, Bring up Context Menu Over Selected Link.[/COLOR]",'','')
        r = re.compile(r'rel="nofollow" href="([^"]*?)" class="myButton" style=".+?">Click here to Play</a>',re.M|re.DOTALL).findall(html)
        for url in r:
            url = base_url+url    
            #main.addDown2(name.strip(),url,840,'.png','.png')
            PLAY(name,url)

            
          
#adding Resolver

def PLAY2(name,url):
        html = main.OPENURL(url)
        r = re.compile(r'DELETE',re.M|re.DOTALL).findall(html)
        for url in r:
         play=xbmc.Player().play(url)
        try: _addon.resolve_url(url)
        except: pass
        
        PL=xbmc.PlayList(xbmc.PLAYLIST_VIDEO); PL.clear(); 
        try:
                import urlresolver
                stream_url=urlresolver.HostedMediaFile(str(url)).resolve()
                PL.add(stream_url,listitem)
                play.play(PL)
        except: pass                   
          

def PLAY(name,url):
        sources = []
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\\','')
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Opening Link,2000)")
        match=re.compile('rel="canonical" href="([^"]*)"/><script>').findall(link)
        for url in match:
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('link rel="canonical" href="([^>]*)" />').findall(link)
        for url in match:
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('location.href = \'([^>]*)\';').findall(link)
        for url in match:
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('value="[[]URL[]]([^"]*)[[]/URL[]]">').findall(link)
        for url in match:
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('<input type="hidden" name="id" value="([^<]*)"><input type="hidden".+?<a href="http://allmyvideos.net">Home</a>').findall(link)
        for url in match:
                url = 'http://allmyvideos.net/' + url
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('name="id" value="([^"]*)"><input type="hidden".+?<a href="http://played.to/" style=".+?">Home</a>').findall(link)
        for url in match:
                url = 'http://played.to/' + url
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('onFocus="copy[(]this[)];"><a href="([^"]*)">').findall(link)
        for url in match:
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)
        match=re.compile('value="([^"]*)"><br><label for="html').findall(link)
        for url in match:
                print "PLAY THIS " +url
                hosted_media = urlresolver.HostedMediaFile(url=url)
                sources.append(hosted_media)        
                
                 
        if (len(sources)==0):
                xbmc.executebuiltin("XBMC.Notification(Sorry!,Show doesn't have playable links,5000)")
      
        else:
                source = urlresolver.choose_source(sources)
                if source:
                        stream_url = source.resolve()
                        if source.resolve()==False:
                                xbmc.executebuiltin("XBMC.Notification(Sorry!,Link Cannot Be Resolved,5000)")
                                return
                else:
                      stream_url = False
                      return
                listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
                listitem.setInfo('video', {'Title': name, 'Year': ''} )       
                xbmc.Player().play(str(stream_url), listitem)
                main.addDir('','','','')      

def Searchhistory():
    seapath=os.path.join(main.datapath,'Search')
    SeaFile=os.path.join(seapath,'SearchHistoryTV')
    if not os.path.exists(SeaFile):
        SEARCH()
    else:
        main.addDir('Search Shows','###',841,art+'/search.png')
        main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
        thumb=art+'/link.png'
        searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
        for seahis in reversed(searchis):
            url=seahis
            seahis=seahis.replace('%20',' ')
            main.addDir(seahis,url,841,thumb)

            

def SEARCH(url = ''):
        encode = main.updateSearchFile(url,'TV')
        if not encode: return False   
        surl='http://tvlinks1.com/search/' + encode
        link=main.OPENURL(surl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('<h2><a href="([^"]*?)">([^"]*?)</a></h2>').findall(link)
        for url,name in match:
          main.addDirTE(name,url,846,'','','','','','')

        nextpage = re.compile('DELETE').findall(link)
        for url in nextpage:
         main.addDir('[COLOR blue]''Next Page >>''[/COLOR]',url,841,'')
                
         xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
        main.VIEWS()
            







