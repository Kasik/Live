import urllib,urllib2,re,cookielib,urlresolver,os,sys
import xbmc, xbmcgui, xbmcaddon, xbmcplugin, string
import main

from t0mm0.common.addon import Addon
from resources.universal import playbackengine, watchhistory
addon_id = 'plugin.video.movie25'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon('plugin.video.vdeobull', sys.argv)
art = main.art
MainUrl='http://www.tvonline.tw'


def TVONLINETW(index=False):  #919
        main.addDir('New Episodes','http://www.tvonline.tw/new-episodes/',921,art+'/.png')
        main.addDir('Latest Added','http://www.tvonline.tw/latest-added/',922,art+'/.png')
        main.addDir('Tv Listings','http://www.tvonline.tw/tv-listings/a',920,art+'/az.png')        
        main.addDir('Genres','http://www.tvonline.tw/genres/action',924,art+'/.png')
        main.addDir('Search',MainUrl,928,art+'/search.png')
        main.VIEWSB()


def TOTWAtoZ():  #920
        main.addDir('0-9','http://www.tvonline.tw/tv-listings/0-9',923,art+'/09.png')
        for i in string.ascii_uppercase:
            main.addDir(i,'http://www.tvonline.tw/tv-listings/'+i.lower(),923,art+'/'+i.lower()+'.png')
           
        

def List(url,index=False):  #921
        link=main.OPEN_URL(url)
        match=re.compile('<li><a href="/([^"]*)/season([^"]*)">([^"]*?)</a></li>').findall(link)
        if len(match) > 0:
         dialogWait = xbmcgui.DialogProgress()
         ret = dialogWait.create('Please wait until Show list is cached.')
         totalLinks = len(match)
         loadedLinks = 0
         remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
         dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
         for url1,url2,name in match:
            url = MainUrl + '/'+ url1 + '/'+ 'season' + url2     
            main.addDirTE(name,url,927,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
         dialogWait.close()
         del dialogWait
      

def List2(url,index=False):  #922
        link=main.OPEN_URL(url)
        match=re.compile('<li><a href="([^"]*)" >([^"]*)</a></li>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url,name in match:
            name=name.replace('&#8211;',' - ').replace('&#039;',"'")
            url = MainUrl + url
            main.addDirTE(name,url,925,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
        dialogWait.close()
        del dialogWait



def List3(url,index=False):  #923
        link=main.OPEN_URL(url)
        match=re.compile('<a href="([^"]*)">([^"]*)</a> </li>').findall(link)
        if len(match) > 0:
         dialogWait = xbmcgui.DialogProgress()
         ret = dialogWait.create('Please wait until Show list is cached.')
         totalLinks = len(match)
         loadedLinks = 0
         remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
         dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
         for url,name in match:
            url = MainUrl + url
            main.addDirTE(name,url,925,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
         dialogWait.close()
         del dialogWait




def GENRES(url):   #924
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('<a href="(/genres/.+?)">([^"]*)</a></li>').findall(link)
        for url,name in match:
         url = MainUrl + url       
         main.addDir(name,url,923,'')       

    

def SEASONS(url):  #925
        main.addLink("[COLOR yellow]-SEASONS-[/COLOR]",'','')
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('<h3><a href=\'([^"]*?)\'>([^"]*?)</a></h3>').findall(link)
        for url,name in match:
         url = MainUrl + url       
         main.addDir(name,url,926,'')       

        

def EPS(url):  #926
        main.addLink("[COLOR yellow]-EPISODES-[/COLOR]",'','')
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('<li><a href=\'([^"]*?)\'><strong>(Episode)</strong>([^"]*?)</a></li>').findall(link)
        for url,name,ep in match:
         url = MainUrl + url       
         main.addDir(name+ep,url,927,'')

        
            
        
def GRABLINKS(name,url):    #927
        main.addLink("[COLOR red]For Download Options, Bring up Context Menu Over Selected Link.[/COLOR]",'','')
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('id="linkname_nav"><li class=""><a href="javascript:" onclick="go_to[(].+?,\'([^"]*?)\'[)];">([^"]*?)</a></li>').findall(link)
        for urls,host in match:
          main.addDown2(name+" [COLOR blue] "+host.upper()+"[/COLOR]",str(urls),930,art+'/hosts/'+host+'.png',art+'/hosts/'+host+'.png')


                       
                    
        
        
#################################################
def PLAYB(name,murl):   #930
    ok=True
    hname=name
    name  = name.split('[COLOR blue]')[0]
    name  = name.split('[COLOR red]')[0]
    infoLabels = main.GETMETAT(name,'','','')
    video_type='movie'
    season=''
    episode=''
    img=infoLabels['cover_url']
    fanart =infoLabels['backdrop_url']
    imdb_id=infoLabels['imdb_id']
    infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':str(infoLabels['title']), 'imdb_id':str(infoLabels['imdb_id']), 'season':str(season), 'episode':str(episode), 'year':str(infoLabels['year']) }

    try:
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
        #stream_url = main.resolve_url(murl)
        stream_url = urlresolver.resolve(murl)

        infoL={'Title': infoLabels['metaName'], 'Plot': infoLabels['plot'], 'Genre': infoLabels['genre']}
        # play with bookmark
        from resources.universal import playbackengine
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=stream_url, addon_id=addon_id, video_type=video_type, title=str(infoLabels['title']),season=str(season), episode=str(episode), year=str(infoLabels['year']),img=img,infolabels=infoL, watchedCallbackwithParams=main.WatchedCallbackwithParams,imdb_id=imdb_id)
        player.KeepAlive()
        return ok
    except Exception, e:
        if stream_url != False:
                main.ErrorReport(e)
        return ok

#################################################          
def PLAYDIS(name,murl):
    ok=True
    hname=name
    name  = name.split('[COLOR blue]')[0]
    name  = name.split('[COLOR red]')[0]
    infoLabels = main.GETMETAT(name,'','','')
    video_type='movie'
    season=''
    episode=''
    img=infoLabels['cover_url']
    fanart =infoLabels['backdrop_url']
    imdb_id=infoLabels['imdb_id']
    infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':str(infoLabels['title']), 'imdb_id':str(infoLabels['imdb_id']), 'season':str(season), 'episode':str(episode), 'year':str(infoLabels['year']) }

    try:
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
        stream_url = urlresolver(murl)

        infoL={'Title': infoLabels['metaName'], 'Plot': infoLabels['plot'], 'Genre': infoLabels['genre']}
        # play with bookmark
        from resources.universal import playbackengine
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=stream_url, addon_id=addon_id, video_type=video_type, title=str(infoLabels['title']),season=str(season), episode=str(episode), year=str(infoLabels['year']),img=img,infolabels=infoL, watchedCallbackwithParams=main.WatchedCallbackwithParams,imdb_id=imdb_id)
        player.KeepAlive()
        return ok
    except Exception, e:
        if stream_url != False:
                main.ErrorReport(e)
        return ok




def Searchhistory():  #928
    seapath=os.path.join(main.datapath,'Search')
    SeaFile=os.path.join(seapath,'SearchHistoryTV')
    if not os.path.exists(SeaFile):
        SEARCH()
    else:
        main.addDir('Search Shows','###',929,art+'/search.png')
        main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
        thumb=art+'/link.png'
        searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
        for seahis in reversed(searchis):
            url=seahis
            seahis=seahis.replace('%20',' ')
            main.addDir(seahis,url,929,thumb)

            

def SEARCH(url = ''): #929
        encode = main.updateSearchFile(url,'TV')
        if not encode: return False
        surl='http://www.tvonline.tw/search.php?key=' + encode 
        link=main.OPEN_URL(surl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('&#8211;','-').replace('amp;','').replace("&#8217;","'")
        match=re.compile('<li><a href="([^"]*?)" target="_blank">([^"]*?)</a> </li>').findall(link)
        for url,name in match:
           main.addDirTE(name,MainUrl+'/'+url,925,'','','','','','')




        
