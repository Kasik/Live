import urllib,urllib2,re,cookielib,urlresolver,os,sys
import xbmc, xbmcgui, xbmcaddon, xbmcplugin, string
import main
import base64
from t0mm0.common.addon import Addon
from resources.universal import playbackengine, watchhistory

art = main.art
MainUrl='http://www.merdb.es/'

#hosts = 'vidbull.com,vidzi.tv,nowvideo.sx,nosvideo.com,movshare.net,noslocker.com,bestreams.net'
hosts = 'vidbull,vidzi,nowvideo,nosvideo,movshare,noslocker,bestreams,novamov,cloudtime,mightyupload,uploadc,zalaa,vidto,cloudzilla'


def MERDBMAIN(index=False):  #905
        main.addDir('Popular Movies','http://www.merdb.es/?sort=views',907,art+'/.png')
        main.addDir('Movies by Rating','http://www.merdb.es/?sort=ratingp',907,art+'/.png')
        main.addDir('Movies Most Favorited','http://www.merdb.es/?sort=favorite',907,art+'/.png')
        main.addDir('Movies by Release Date','http://www.merdb.es/?sort=year',907,art+'/.png')
        main.addDir('Movies by Date Added','http://www.merdb.es/?sort=stamp',907,art+'/.png')
        main.addDir('Movies A-Z','http://www.merdb.es/?sort=startwith',907,art+'/.png')
        main.addDir('Featured Movies','http://www.merdb.es/?sort=featured',907,art+'/.png')
        main.addDir('Genres',MainUrl,909,art+'/.png')
        main.addDir('Years',MainUrl,910,art+'/.png')

        main.addDir('TV Shows','http://www.merdb.es/tvshow/index.php',906,art+'/.png')

        main.addDir('Search Movies','http://www.merdb.es/?search=',0001,art+'/search.png')
        main.VIEWSB()

def TVSHOWS(index=False):  #906
        main.addDir('Popular Shows','http://www.merdb.es/tvshow/?sort=views',908,art+'/.png')
        main.addDir('Shows by Rating','http://www.merdb.es/tvshow/?sort=ratingp',908,art+'/.png')
        main.addDir('Shows Most Favorited','http://www.merdb.es/tvshow/?sort=favorite',908,art+'/.png')
        main.addDir('Shows by Release Date','http://www.merdb.es/tvshow/?sort=year',908,art+'/.png')
        main.addDir('Shows by Date Added','http://www.merdb.es/tvshow/?sort=stamp',908,art+'/.png')
        main.addDir('Shows A-Z','http://www.merdb.es/tvshow/?sort=startwith',908,art+'/.png')
        main.addDir('Featured Shows','http://www.merdb.es/tvshow/?sort=ratingp',908,art+'/latest.png')
        main.addDir('Genres','http://www.merdb.es/tvshow/index.php',911,art+'/.png')
        main.addDir('Years','http://www.merdb.es/tvshow/index.php',912,art+'/.png')
        main.addDir('Search Shows','http://www.merdb.es/tvshow/?search=',908,art+'/search.png')
        main.VIEWSB()

      

def List(url,index=False): # 907
        link=main.OPEN_URL(url)
        match=re.compile('<a href=".+?" title=".+?"><img src="//([^"]*?)" class="main_list_picsize" alt=".+?"/></a><div class="list_box_title"><a href="([^"]*?html)" title=".+?">([^"]*?)</a>').findall(link)
        if len(match) > 0:
         dialogWait = xbmcgui.DialogProgress()
         ret = dialogWait.create('Please wait until Show list is cached.')
         totalLinks = len(match)
         loadedLinks = 0
         remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
         dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
         for thumb,url,name in match:
            url = MainUrl + url     
            main.addInfo(name,url,915,thumb,'','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
         dialogWait.close()
         del dialogWait
         paginate=re.compile('<a href="([^"]*?)">></a>').findall(link)
         if paginate:
          xurl=MainUrl+paginate[0]         
          main.addDir('[COLOR blue]Next Page'+'[/COLOR]',xurl,907,art+'/next2.png') 
                    



def List2(url,index=False): # 908
        link=main.OPEN_URL(url)
        match=re.compile('<a href="([^"]*?html)" title=".+?"><img src="//([^"]*?)" class="main_list_picsize" alt=".+?"/></a><div class="list_box_title"><a href=".+?" title=".+?">([^"]*?)</a>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url,thumb,name in match:
            name=name.replace('&#8211;',' - ').replace('&#039;',"'")
            url = MainUrl + url
            #main.addPlayTE(name+' [COLOR red]'+date+'[/COLOR]',url,5,'','','','','','')
            main.addDirTE(name+' [COLOR red]'+date+'[/COLOR]',url,913,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
        dialogWait.close()
        del dialogWait

        paginate=re.compile('<a href="([^"]*?)">></a>').findall(link)
        if paginate:
          xurl=MainUrl+paginate[0]         
          main.addDir('[COLOR blue]Next Page'+'[/COLOR]',xurl,908,art+'/next2.png') 



def GENRES(name,url):  #909    
        link = main.OPEN_URL(url)
        r = re.compile(r'<a href="/[?]genre=([^"]*?)" title=".+?">([^"]*?)</a>',re.M|re.DOTALL).findall(link)
        for url,name in r:
          url = MainUrl + '/?genre=' + url      
          main.addDir(name,url,907,'','')
          

def YEARS(name,url):  #910    
        link = main.OPEN_URL(url)
        r = re.compile(r'a href="/[?]year=([^"]*?)" title=".+?">([^"]*?)</a>',re.M|re.DOTALL).findall(link)
        for url,name in r:
          url = MainUrl + '/?year=' + url      
          main.addDir(name,url,907,'','')

def TVGENRES(name,url):  #911    
        link = main.OPEN_URL(url)
        r = re.compile(r'<a href="/tvshow/[?]genre=([^"]*)" title=".+?">([^"]*)</a>',re.M|re.DOTALL).findall(link)
        for url,name in r:
          url = MainUrl + '/tvshow/?genre=' + url      
          main.addDir(name,url,908,'','')
          

def TVYEARS(name,url):  #912   
        link = main.OPEN_URL(url)
        r = re.compile(r'<a href="/tvshow/[?]year=([^"]*?)" title=".+?">([^"]*?)</a>',re.M|re.DOTALL).findall(link)
        for url,name in r:
          url = MainUrl + '/tvshow/?year=' + url      
          main.addDir(name,url,908,'','')          



def TVSEASON(name,url): #913
        link = main.OPEN_URL(url)
        r = re.compile(r'class="season-toggle" href="([^"]*?)">&#9658;([^"]*?)<span',re.M|re.DOTALL).findall(link)
        for url,name in r:
          url = MainUrl + url      
          main.addDir(name,url,914,'','')

def TVEPS(name,url): #914
        link = main.OPEN_URL(url)
        r = re.compile(r'<a href="([^"]*?)">.+?<span class="tv_episode_name"> -([^"]*?)</span><span class="tv_episode_airdate"> -([^"]*?)</span><span class="tv_num_versions">[[]([^"]*?)[]]',re.M|re.DOTALL).findall(link)
        for url,name,date,links in r:
          url = MainUrl + url      
          main.addDir(name + date + links ,url,915,'','') 
     
                           
             
def LINKS(name,url):  #915
        link = main.OPEN_URL(url)
        link = link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')                   
        main.addLink("[COLOR yellow]For Download Options, Bring up Context Menu Over Selected Link.[/COLOR]",'','')
        match=re.compile('class="movie_version_link"><a href="/external.php[?]title=.+?&url=([^"]*?)&domain=.+?&loggedin=0".+?<span class="version_host">\'([^"]*?)\'</span>').findall(link)
        for url,host in match:
         host=host.replace('.com','').replace('.net','').replace('.tv','').replace('.sx','').replace('.to','').replace('.me','')              
         if host in hosts:
          regexlink = url
          url = base64.b64decode(regexlink)
          hostUrl = url
          print "DECODED URL ::" + hostUrl        
          main.addDown2(name.strip()+" [COLOR blue]"+host.upper()+"[/COLOR]",hostUrl,916,art+'/hosts/'+host+'.png',art+'/hosts/'+host+'.png')        
        else:
         return False
       
                                                                      
        
        
#################################################
def PLAYB(name,murl):   #916
    ok=True
    hname=name
    name  = name.split('[COLOR blue]')[0]
    name  = name.split('[COLOR red]')[0]
    infoLabels = main.GETMETAT(name,'','','')
    video_type='movie'
    season=''
    episode=''
    img=infoLabels['cover_url']
    fanart =infoLabels['backdrop_url']
    imdb_id=infoLabels['imdb_id']
    infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':str(infoLabels['title']), 'imdb_id':str(infoLabels['imdb_id']), 'season':str(season), 'episode':str(episode), 'year':str(infoLabels['year']) }
        
    try:
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
        #stream_url = main.resolve_url(murl)
        stream_url = urlresolver.resolve(hostUrl)

        infoL={'Title': infoLabels['metaName'], 'Plot': infoLabels['plot'], 'Genre': infoLabels['genre']}
        # play with bookmark
        from resources.universal import playbackengine
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=stream_url, addon_id=addon_id, video_type=video_type, title=str(infoLabels['title']),season=str(season), episode=str(episode), year=str(infoLabels['year']),img=img,infolabels=infoL, watchedCallbackwithParams=main.WatchedCallbackwithParams,imdb_id=imdb_id)
        player.KeepAlive()
        return ok
    except Exception, e:
        if stream_url != False:
                main.ErrorReport(e)
        return ok

#################################################          
def PLAYDIS(name,murl):
    ok=True
    hname=name
    name  = name.split('[COLOR blue]')[0]
    name  = name.split('[COLOR red]')[0]
    infoLabels = main.GETMETAT(name,'','','')
    video_type='movie'
    season=''
    episode=''
    img=infoLabels['cover_url']
    fanart =infoLabels['backdrop_url']
    imdb_id=infoLabels['imdb_id']
    infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':str(infoLabels['title']), 'imdb_id':str(infoLabels['imdb_id']), 'season':str(season), 'episode':str(episode), 'year':str(infoLabels['year']) }

    try:
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
        stream_url = urlresolver(murl)

        infoL={'Title': infoLabels['metaName'], 'Plot': infoLabels['plot'], 'Genre': infoLabels['genre']}
        # play with bookmark
        from resources.universal import playbackengine
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=stream_url, addon_id=addon_id, video_type=video_type, title=str(infoLabels['title']),season=str(season), episode=str(episode), year=str(infoLabels['year']),img=img,infolabels=infoL, watchedCallbackwithParams=main.WatchedCallbackwithParams,imdb_id=imdb_id)
        player.KeepAlive()
        return ok
    except Exception, e:
        if stream_url != False:
                main.ErrorReport(e)
        return ok




def Searchhistory():  # 917
    seapath=os.path.join(main.datapath,'Search')
    SeaFile=os.path.join(seapath,'SearchHistoryTV')
    if not os.path.exists(SeaFile):
        SEARCH()
    else:
        main.addDir('Search Shows','###',867,art+'/search.png')
        main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
        thumb=art+'/link.png'
        searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
        for seahis in reversed(searchis):
            url=seahis
            seahis=seahis.replace('%20',' ')
            main.addDir(seahis,url,867,thumb)
       

def SEARCH(url = ''):  #918
        encode = main.updateSearchFile(url,'TV')
        if not encode: return False
        surl='http://www.merdb.es/?search=' + encode 
        link=main.OPENURL(surl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('DELETE').findall(link)
        if len(match) > 0:
          for url,name,thumb in match:
           main.addDir(name,url,864,thumb)
        paginate=re.compile('DELETE').findall(link)
        if paginate:
           xurl=paginate[0]         
           main.addDir('[COLOR blue]Next Page'+'[/COLOR]',xurl,867,art+'/next2.png') 
