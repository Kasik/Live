# -*- coding: cp1252 -*-
import urllib,re,string,sys,os
import xbmc,xbmcgui,xbmcaddon,xbmcplugin
from resources.libs import main

#Mash Up - by Mash2k3 2012.

addon_id = 'plugin.video.movie25'
selfAddon = xbmcaddon.Addon(id=addon_id)
art = main.art
prettyName = 'WatchSeries'
gurl='http://watchseries.ag'

def MAINWATCHS(index=False):
        main.addDir('Search','s',581,art+'/search.png',index=index)
        main.addDir('A-Z','s',577,art+'/az.png',index=index)
        main.addDir('Yesterdays Episodes','http://watchseries.ag/tvschedule/-2',573,art+'/yesepi.png',index=index)
        main.addDir('Todays Episodes','http://watchseries.ag/tvschedule/-1',573,art+'/toepi2.png',index=index)
        main.addDir('Popular Shows','http://watchseries.ag/',580,art+'/popshowsws.png',index=index)
        main.addDir('This Weeks Popular Episodes','http://watchseries.ag/new',573,art+'/thisweek.png',index=index)
        main.addDir('Newest Episodes Added','http://watchseries.ag/latest',573,art+'/newadd.png',index=index)
        main.addDir('By Genre','genre',583,art+'/genre.png',index=index)
        main.VIEWSB()

def POPULARWATCHS(murl,index=False):
        link=main.OPENURL2(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        
        match=re.compile('href="([^"]+)" title=".+?">([^<]+)</a><br />').findall(link)
        main.addLink('[COLOR red]Most Popular Series[/COLOR]','',art+'/link.png')
        for url, name in match[0:12]:
            main.addDirT(name,'http://watchseries.ag'+url,578,'','','','','','',index=index)
        main.addLink('[COLOR red]Most Popular Cartoons[/COLOR]','',art+'/link.png')
        for url, name in match[12:24]:
            main.addDirT(name,'http://watchseries.ag'+url,578,'','','','','','',index=index)
        main.addLink('[COLOR red]Most Popular Documentaries[/COLOR]','',art+'/link.png')
        for url, name in match[24:36]:
            main.addDirT(name,'http://watchseries.ag'+url,578,'','','','','','',index=index)
        main.addLink('[COLOR red]Most Popular Shows[/COLOR]','',art+'/link.png')
        for url, name in match[36:48]:
            main.addDirT(name,'http://watchseries.ag'+url,578,'','','','','','',index=index)
        main.addLink('[COLOR red]Most Popular Sports[/COLOR]','',art+'/link.png')
        for url, name in match[48:60]:
            main.addDirT(name,'http://watchseries.ag'+url,578,'','','','','','',index=index)

            
def GENREWATCHS(index=False):
        main.addDir('Action','http://watchseries.ag/genres/action',576,art+'/act.png',index=index)
        main.addDir('Adventure','http://watchseries.ag/genres/adventure',576,art+'/adv.png',index=index)
        main.addDir('Animation','http://watchseries.ag/genres/animation',576,art+'/ani.png',index=index)
        main.addDir('Comedy','http://watchseries.ag/genres/comedy',576,art+'/com.png',index=index)
        main.addDir('Crime','http://watchseries.ag/genres/crime',576,art+'/cri.png',index=index)
        main.addDir('Documentary','http://watchseries.ag/genres/documentary',576,art+'/doc.png',index=index)
        main.addDir('Drama','http://watchseries.ag/genres/drama',576,art+'/dra.png',index=index)
        main.addDir('Family','http://watchseries.ag/genres/family',576,art+'/fam.png',index=index)
        main.addDir('Fantasy','http://watchseries.ag/genres/fantasy',576,art+'/fant.png',index=index)
        main.addDir('History','http://watchseries.ag/genres/history',576,art+'/his.png',index=index)
        main.addDir('Horror','http://watchseries.ag/genres/horror',576,art+'/hor.png',index=index)
        main.addDir('Music','http://watchseries.ag/genres/music',576,art+'/mus.png',index=index)
        main.addDir('Mystery','http://watchseries.ag/genres/mystery',576,art+'/mys.png',index=index)
        main.addDir('Reality','http://watchseries.ag/genres/reality-tv',576,art+'/rea.png',index=index)
        main.addDir('Sci-Fi','http://watchseries.ag/genres/sci-fi',576,art+'/sci.png',index=index)
        main.addDir('Sport','http://watchseries.ag/genres/sport',576,art+'/spo.png',index=index)
        main.addDir('Talk Show','http://watchseries.ag/genres/talk-show',576,art+'/tals.png',index=index)
        main.addDir('Thriller','http://watchseries.ag/genres/thriller',576,art+'/thr.png',index=index)
        main.addDir('War','http://watchseries.ag/genres/war',576,art+'/war.png',index=index)
        main.VIEWSB()

def AtoZWATCHS(index=False):
    main.addDir('0-9','http://watchseries.ag/letters/09',576,art+'/09.png',index=index)
    for i in string.ascii_uppercase:
            main.addDir(i,'http://watchseries.ag/letters/'+i.lower()+'/list-type/a_z',576,art+'/'+i.lower()+'.png',index=index)
    main.VIEWSB()

def LISTWATCHS(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('<a class=".+?" title=".+?" href="(.+?)">.+?</span>(.+?)</a>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        for url, name in match:
            name=re.sub('\((\d+)x(\d+)\)','',name,re.I)
            episode = re.search('Seas(on)?\.? (\d+).*?Ep(isode)?\.? (\d+)',name, re.I)
            if(episode):
                e = str(episode.group(4))
                if(len(e)==1): e = "0" + e
                s = episode.group(2)
                if(len(s)==1): s = "0" + s
                name = re.sub('Seas(on)?\.? (\d+).*?Ep(isode)?\.? (\d+)','',name,re.I)
                name = name.strip() + " " + "S" + s + "E" + e
            if 'watchseries.' not in name and 'watchtvseries.' not in name:
                    if index == 'True':
                            name=re.sub('(\d{4})','',name.replace(' (','').replace(')',''))
                            main.addDirTE(name,'http://watchseries.ag'+url,21,'','','','','','')
                    else:
                            main.addDirTE(name,'http://watchseries.ag'+url,575,'','','','','','')
                    loadedLinks = loadedLinks + 1
                    percent = (loadedLinks * 100)/totalLinks
                    remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                    dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
                    if (dialogWait.iscanceled()):
                        return False   
        dialogWait.close()
        del dialogWait

def LISTSHOWWATCHS(murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('<a title="(.+?)" href="(.+?)">.+?<span class="epnum">(.+?)</span></a>').findall(link)
        for name, url, year in match:
            main.addDirT(name,'http://watchseries.ag'+url,578,'','','','','','',index=index)

def LISTWATCHSEASON(mname, murl,index=False):
        link=main.OPEN_URL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        thumb=art+'/folder.png'
        match=re.compile('<h2 class="lists"><a class="null" href="([^"]*)">([^"]*)</a></h2>').findall(link)
        #for url, name in reversed(match):
        for url, name in match:
            url = 'http://watchseries.ag' + url
            print url
            main.addDir(mname+' [COLOR red]'+name+'[/COLOR]',murl,579,thumb,index=index)


def LISTWATCHEPISODE(mname, murl,index=False):
        link=main.OPENURL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace("&nbsp;&nbsp;&nbsp;"," ")
        print mname
        #xname=re.findall('(Season .+?)',mname)[0]
        xname=re.findall('(Season [0-9]+)',mname)[0]
        print xname
        #match=re.compile('<a title=".+?- '+xname+' -.+?" href="([^"]+)"><span class="" >([^<]+)</span>').findall(link)
        match=re.compile('<a title=".+?- '+xname+' -([^<]+)" href="([^"]+)"><span class="" >[^<]+</span>').findall(link)
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until Show list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0,'[B]Will load instantly from now on[/B]',remaining_display)
        season = re.search('Seas(on)?\.? (\d+)',main.removeColorTags(mname),re.I)
        #for url, episode in reversed(match):
        for episode, url in match:
            name = mname
            epi= re.search('Ep(isode)?\.? (\d+)(.*)',episode, re.I)
            if(epi):
                e = str(epi.group(2))
                if(len(e)==1): e = "0" + e
                if(season):
                    s = season.group(2)
                    if(len(s)==1): s = "0" + s
                    name = main.removeColoredText(mname).strip()
                    name = name + " " + "S" + s + "E" + e
                    episode = epi.group(3).strip()
            if index == 'True':
                    name=re.sub('(\d{4})','',name.replace(' (','').replace(')',''))
                    main.addDirTE(name + ' [COLOR red]'+str(episode)+'[/COLOR]','http://watchseries.ag'+url,21,'','','','','','')
            else:
                    main.addDirTE(name + ' [COLOR red]'+str(episode)+'[/COLOR]','http://watchseries.ag'+url,575,'','','','','','')
            loadedLinks = loadedLinks + 1
            percent = (loadedLinks * 100)/totalLinks
            remaining_display = 'Episodes loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
            dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
            if (dialogWait.iscanceled()):
                return False   
        dialogWait.close()
        del dialogWait
        if selfAddon.getSetting('auto-view') == 'true':
                xbmc.executebuiltin("Container.SetViewMode(%s)" % selfAddon.getSetting('episodes-view'))

def SearchhistoryWS(index=False):
        seapath=os.path.join(main.datapath,'Search')
        SeaFile=os.path.join(seapath,'SearchHistoryTv')
        if not os.path.exists(SeaFile):
            SEARCHWS(index=index)
        else:
            main.addDir('Search','###',582,art+'/search.png',index=index)
            main.addDir('Clear History',SeaFile,128,art+'/cleahis.png')
            thumb=art+'/link.png'
            searchis=re.compile('search="(.+?)",').findall(open(SeaFile,'r').read())
            for seahis in reversed(searchis):
                    url=seahis
                    seahis=seahis.replace('%20',' ')
                    main.addDir(seahis,url,582,thumb,index=index)

def superSearch(encode,type):
    try:
        returnList=[]
        surl='http://watchseries.ag/search/'+encode
        epi = re.search('(?i)s(\d+?)e(\d+?)$',encode)
        if epi:
            epistring = encode.rpartition('%20')[2].upper()
            e = int(epi.group(2))
            s = int(epi.group(1))
            encodewithoutepi = urllib.quote(re.sub('(?i)(\ss(\d+)e(\d+))|(Season(.+?)Episode)|(\d+)x(\d+)','',urllib.unquote(encode)).strip())
            encode=encodewithoutepi+' season '+str(s)+' episode '+str(e)
            site = 'site:http://watchseries.ag/'
            results = main.SearchGoogle(urllib.unquote(encode), site)
            for res in results:
                t = res.title.encode('utf8').strip('...')
                u = res.url.encode('utf8')
                if type == 'TV':
                    if re.search('(?sim)season '+str(s)+' episode '+str(e),t):
                        t = re.sub('(?i)^[a-z] - (.*?)','\\1',t)
                        t = re.sub('(.*\)).*','\\1',t)
                        t= t.strip(" -").replace("-","").replace(" WatchSeries.lt","").replace(" Watch Series","").replace("Watch Online ","").replace("Watch Online","").replace("  "," ")
                        name=re.sub('\((\d+)x(\d+)\)','',t,re.I)
                        episode = re.search('Seas(on)?\.? (\d+).*?Ep(isode)?\.? (\d+)',name, re.I)
                        if(episode):
                            e = str(episode.group(4))
                            if(len(e)==1): e = "0" + e
                            s = episode.group(2)
                            if(len(s)==1): s = "0" + s
                            name = re.sub('Seas(on)?\.? (\d+).*?Ep(isode)?\.? (\d+)',"S" + s + "E" + e,name,re.I).strip()
                            name = re.sub('(?i)(s\d+e\d+\s?)(.*?)$','\\1[COLOR blue]\\2[/COLOR]',name)
                        returnList.append((name,prettyName,u,'',575,True))
                        return returnList
        link=main.OPENURL(surl,verbose=False)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        match=re.compile('<img src="([^"]+?)">               </a>.*?<a title="[^"]+?" href="([^<]+)"><b>(.+?)</b>',re.DOTALL).findall(link)
        for thumb,url,name in match:
            url = 'http://watchseries.ag' + url
            returnList.append((name,prettyName,url,thumb,578,True))
        return returnList
    except: return []
            
def SEARCHWS(murl = '',index=False):
        encode = main.updateSearchFile(murl,'TV')
        if not encode: return False   
        surl='http://watchseries.ag/search/'+encode
        link=main.OPENURL(surl)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('<a title=".+?" href=".+?">.+?<img src="([^"]*)">.+?href="([^"]*)"><b>([^"]*)</b></a>.+?<b>Description:</b>([^"]*)</td></tr>',re.DOTALL).findall(link)
        for thumb,url,name,desc in match:
                main.addDirT(name,'http://watchseries.ag'+url,578,thumb,desc,'','','','',index=index)



def LISTHOST(name,murl):
        link=main.OPEN_URL(murl)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('  ','')
        if selfAddon.getSetting("hide-download-instructions") != "true":
            main.addLink("[COLOR red]For Download Options, Bring up Context Menu Over Selected Link.[/COLOR]",'','')
        match=re.compile('<span>(.+?)</span></td><td> <a target="_blank" href="([^"]*)" class').findall(link)
        for host,url in match:
                host=host.replace('.com','')
                main.addDir(name.strip()+" [COLOR blue]"+host.upper()+"[/COLOR]",gurl+url,574,art+'/hosts/'+host+'.png',art+'/hosts/'+host+'.png')    
        

def LINKWATCHS(name,url):
        link=main.OPEN_URL(url)
        link=link.replace('\r','').replace('\n','').replace('\t','')
        match=re.compile('<a class="myButton" href="([^"]*)">Click Here to Play</a>').findall(link)
        #if len(match) > 0:
        for url in match:
          name = 'PLAY'       
          main.addDown2(name,gurl+url,597,'.png','.png')    
     

def PLAYWATCHSLINK(name,url):
    ok=True
    hname=name
    name  = name.split('[COLOR blue]')[0]
    name  = name.split('[COLOR red]')[0]
    infoLabels = main.GETMETAT(name,'','','')
    video_type='movie'
    season=''
    episode=''
    img=infoLabels['cover_url']
    fanart =infoLabels['backdrop_url']
    imdb_id=infoLabels['imdb_id']
    infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':str(infoLabels['title']), 'imdb_id':str(infoLabels['imdb_id']), 'season':str(season), 'episode':str(episode), 'year':str(infoLabels['year']) }

    try:
        xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
        stream_url = urlresolver.resolve(url)

        infoL={'Title': infoLabels['metaName'], 'Plot': infoLabels['plot'], 'Genre': infoLabels['genre']}
        # play with bookmark
        from resources.universal import playbackengine
        player = playbackengine.PlayWithoutQueueSupport(resolved_url=stream_url, addon_id=addon_id, video_type=video_type, title=str(infoLabels['title']),season=str(season), episode=str(episode), year=str(infoLabels['year']),img=img,infolabels=infoL, watchedCallbackwithParams=main.WatchedCallbackwithParams,imdb_id=imdb_id)
        player.KeepAlive()
        return ok
    except Exception, e:
        if stream_url != False:
                main.ErrorReport(e)
        return ok


